package com.cesur.servicio;

import com.cesur.modelo.Restaurante;
import com.cesur.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class RestauranteService {

    public void registrarRestaurante(String nombre, String ciudad) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = session.beginTransaction();

        Restaurante restaurante = new Restaurante(nombre, ciudad);
        session.persist(restaurante);

        tx.commit();
        session.close();
    }
}
