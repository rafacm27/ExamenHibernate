package com.cesur;

import com.cesur.servicio.RestauranteService;

public class Main {
    public static void main(String[] args) {
        RestauranteService servicio = new RestauranteService();
        servicio.registrarRestaurante("La Parrilla", "Sevilla");
        servicio.registrarRestaurante("Tacos El Güey", "Madrid");
    }
    
}
